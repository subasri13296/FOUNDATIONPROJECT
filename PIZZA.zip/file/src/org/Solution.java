package org;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.Pizza;
import com.Cart;
import com.account.Address;

public class Solution {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Enter DoorNumber : ");
		String doorNumber = br.readLine();
		
		System.out.print("Enter StreetName : ");
		String streetName = br.readLine();
		
		System.out.print("Enter Loaction : ");
		String location = br.readLine();
		
		System.out.print("Enter City : ");
		String city = br.readLine();
		
		System.out.print("Enter State : ");
		String state = br.readLine();
		
		System.out.print("Enter pincode : ");
		int pincode = Integer.valueOf(br.readLine());
		
		System.out.print("Enter PhoneNumber : ");
		String phoneNumber = br.readLine();
		
		Address address = new Address(doorNumber, streetName, location, city, state, pincode, phoneNumber);
		System.out.print("Enter name : ");
		String name = br.readLine();
		Cart cart = new Cart(name, address);
		List<Pizza> pizzaList = new ArrayList<Pizza>();
		pizzaList.add(new Pizza("PZ01", "Veggie Surprise", "Capsicum, onion,Sweet Corn, Paprika", "Medium", 399.0));
		pizzaList.add(new Pizza("PZ02", "Paneer Delight", " onion,Tomato,Sweet Corn,Jalapeno", "Medium", 349.0));
		pizzaList.add(new Pizza("PZ03", "chicken Hot n Spicy", "Red Paprika, onion,Jalapeno", "Medium", 499.0));
		pizzaList.add(new Pizza("PZ04", "Tikka Treat", "Capsicum, onion,Mushroom", "Medium", 599.0));

		while (true) {

			System.out.print("Enter choice : ");
			int choice = Integer.valueOf(br.readLine());
			if (choice == 1) {
				System.out.print("Enter pizza id : ");
				int selection = Integer.valueOf(br.readLine());
				cart.addPizza(pizzaList.get(selection - 1));
			} else if (choice == 2) {
				System.out.print("Enter pizza id : ");
				int selection = Integer.valueOf(br.readLine());
				cart.removePizza(pizzaList.get(selection - 1));
			}
			System.out.print("Enter choice of exiting");
			String next = br.readLine();
			if (next.equals("no")) {
				System.out.println("Name : "+name);
				System.out.println("Delivery Address :");
				System.out.println("----------------------");
				System.out.println(address.toString());
				System.out.println("----------------------------------------------------------------------------------------");
				System.out.println("ID   NAME OF PIZZA       TOPPINGS                                SIZE      PRICE");
				System.out.println("----------------------------------------------------------------------------------------");
				System.out.println(cart.toString());
				break;
			}

		}

	}

}
