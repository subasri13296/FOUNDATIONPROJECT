package com;

import java.util.ArrayList;
import java.util.List;

import com.account.Address;

public class Cart {
	private String name;
	private Address address;
	private double totalAmount=0.0;
	List<Pizza> orders = new ArrayList<Pizza>();
	
	public Cart(String name, Address address) {
		super();
		this.name = name;
		this.address = address;
	
	}
	
	
	
	



	@Override
	public String toString() {
		return String.format(""+orders+"\n"+totalAmount);
				
	}







	public List<Pizza> getOrders() {
		return orders;
	}



	public void setOrders(List<Pizza> orders) {
		this.orders = orders;
	}



	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public void addPizza(Pizza pizza){
		orders.add(pizza);
		totalAmount+=pizza.getPrice();
	}
    public void removePizza(Pizza pizza){
    	orders.remove(pizza);
    	totalAmount-=pizza.getPrice();
	}

}
